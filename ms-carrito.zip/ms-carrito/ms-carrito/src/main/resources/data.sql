
DELETE FROM carritos;


INSERT INTO carritos
(usuario_id, total, cantidad_productos, fecha_creacion)
VALUES
(1, 159990, 3, CURRENT_TIMESTAMP),
(2, 45990, 1, CURRENT_TIMESTAMP),
(3, 99990, 2, CURRENT_TIMESTAMP),
(4, 250000, 5, CURRENT_TIMESTAMP),
(5, 79990, 1, CURRENT_TIMESTAMP);